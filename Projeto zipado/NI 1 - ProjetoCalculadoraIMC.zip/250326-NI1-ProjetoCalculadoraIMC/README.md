# Informações do aluno
- Nome: Gabriel Debastiani Davanço<br>
- RA: 24025899

# Descrição do projeto
O aplicativo tem como função calcular e mostra o IMC (Índice de Massa Corporal), e além de mostrar a classificação do usuário na escala do IMC, ainda conta com uma mensagem de feedback positivo e motivacional.<br>
O projeto foi desenvolvivo com o intuito de melhor fixar alguns conceitos fundamentais da ferramenta Android Studio:
- Criação de TextView's
- Manipulação de TextView's
- Criação e utilização de Values em xml
- Utilização de EditText's
- Inclusão de imagens
- Troca de telas com Intent
- Passagem de informações entre telas com Bundle

# Descrição do processo de desenvolvimento
Alguns desafios durante o processo foram:
- Achar o tempo para concluir o projeto
- Achar imagens condizentes com a situação
- Algumas questões de lógica do programa (onde inicializar a variavel por exemplo)
  
